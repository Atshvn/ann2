import { ImgUploadTemp } from "../../Common";
import LayoutMain from "../../layout/LayoutMain";

export const Dashboard = () => {
  return (
    <LayoutMain>
      <div className="container-fluid">
        <div className="row cardcus ">
          <div className="row margin-left-0">
            <div className="col-md-12 HomeTitle">Danh sách</div>
          </div>
          <div className="row margin-left-0 width100 new margin-top-10">
            <div className="col-md-12">
              <ImgUploadTemp data=""></ImgUploadTemp>              
            </div>
          </div>
        </div>
      </div>
    </LayoutMain>
  );
};
