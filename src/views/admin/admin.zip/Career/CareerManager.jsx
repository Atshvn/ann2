import LayoutMain from "../../layout/LayoutMain";
export const CareerManager = () => {
    return (<LayoutMain></LayoutMain>)
}