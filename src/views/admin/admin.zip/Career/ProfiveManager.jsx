import LayoutMain from "../../layout/LayoutMain";
export const ProfiveManager = () => {
    return (<LayoutMain></LayoutMain>)
}