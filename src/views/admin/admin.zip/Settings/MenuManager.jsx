import LayoutMain from "../../layout/LayoutMain";
export const MenuManager = () => {
    return (<LayoutMain></LayoutMain>)
}