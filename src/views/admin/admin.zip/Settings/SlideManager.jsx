import LayoutMain from "../../layout/LayoutMain";
export const SlideManager = () => {
    return (<LayoutMain></LayoutMain>)
}