import LayoutMain from "../../layout/LayoutMain";
export const PageSetting = () => {
    return (<LayoutMain></LayoutMain>)
}