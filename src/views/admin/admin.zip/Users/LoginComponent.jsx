import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { Notification, EncodeString } from "../../Utils";
import { mainAction } from "../../Redux/Actions";
import { useInput } from "../../Hooks";
import LayoutLogin from "../../layout/LayoutLogin";

export const LoginComponent = () => {
  const dispatch = useDispatch();

  const [Username, bindUserName, setUsername] = useInput("");
  const UsernameRef = useRef();

  const [Password, bindPassword, setPassword] = useInput("");
  const PasswordRef = useRef();

  const [LoginMessage, setLoginMessage] = useState("");
  const [disable, setDisable] = useState(false); // disable button
  const navigate = useNavigate();

  const [UserActive, setUserActive] = useState("");
  const [PassActive, setPassActive] = useState("");

  const [PassHide, setPassHide] = useState("password");
  const [PassEye, setPassEye] = useState("");

  useEffect(() => {
    localStorage.setItem("login", "");
    let currentDate = new Date();
    if (currentDate.getHours() < 12)
      setLoginMessage("Chào buổi sáng. Chúc bạn ngày mới tràn đầy năng lượng");
    else if (currentDate.getHours() > 12 && currentDate.getHours() < 18)
      setLoginMessage("Buổi chiều của bạn thế nào ?");
    else setLoginMessage("Hôm nay có gì mới ?");
  }, []);

  const onClickLogin = async () => {
    setDisable(true);
    setUserActive("");
    setPassActive("");
    if (Username === "") {
      Notification('error',"Thông tin đăng nhập không được để trống");
      setUserActive("form-error");
      setDisable(false);
      return;
    } else if (Password === "") {
      Notification('error',"Mật khẩu không được để trống");
      setUserActive("");
      setPassActive("form-error");
      setDisable(false);
      return;
    } else {
      let prj = {
        UserName:Username,
        Password: Password,
        Uid:0
      };
      // if(Username==="admin" && Password==="admin"){
      //   localStorage.setItem("LoginData",EncodeString(JSON.stringify(prj)));
      // }
      // else{
      //   Notification('error',"Tài khoản hoặc mật khẩu không đúng");
      // }
      try{

        // const pwd = await mainAction.EncryptString(prj, dispatch);
        let pr = {
          Json: '{"UserName":"' + Username + '","Password":"' + Password + '"}',
          func: "Shop_spUsers_CheckLogin",
        };
        const data = await mainAction.API_spCallServer(pr, dispatch);


        localStorage.setItem("LoginData",EncodeString(JSON.stringify(data[0])));
        navigate.push('/home')

      }
      catch(ex){
        Notification('error',"Lỗi kết nối, liên hệ IT");
      }
    }

    mainAction.LOADING({ IsLoading: false }, dispatch);
  };

  return (
    <LayoutLogin>
      <div className="content-login">
        <div className="container container-login">
          <div className="row">
            <div className="col-md-12 text-center mb10">
              <img
                src="../..LogoNetco.png"
                className="margin-left-5"
                width="200"
              />
            </div>
          </div>
          <div className="row">
            <div className="col-md-6 hide-sm">
              <h3 className="bold">
                <span className="red">NETCO</span> CÓ GÌ HOT ?
              </h3>
              <div className="row margin-top-10">
                <div className="col-md-12 margin-top-10">
                  <h4 className="bold">
                    {" "}
                    <img
                      src="tick.png"
                      className="logocustom"
                      width="20"
                    />{" "}
                    Vận chuyển an toàn{" "}
                  </h4>
                  <div className="italic sm">
                    {" "}
                    Hàng hóa của khách hàng được bảo đảm an toàn tới tay người
                    nhận{" "}
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-12">
                  <h4 className="bold">
                    {" "}
                    <img
                      src="tick.png"
                      className="logocustom"
                      width="20"
                    />{" "}
                    Hỗ trợ tư vấn linh hoạt{" "}
                  </h4>
                  <div className="italic sm">
                    {" "}
                    Khách hàng luôn được chăm sóc chu đáo - nhiệt tình ở mọi
                    thời điểm{" "}
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-12">
                  <h4 className="bold">
                    {" "}
                    <img
                      src="tick.png"
                      className="logocustom"
                      width="20"
                    />{" "}
                    Thanh toán dễ dàng{" "}
                  </h4>
                  <div className="italic sm">
                    {" "}
                    Phương thức thanh toán linh hoạt, tiện lợi mà vẫn giữ được
                    sự an toàn{" "}
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-12">
                  <h4 className="bold">
                    {" "}
                    <img
                      src="tick.png"
                      className="logocustom"
                      width="20"
                    />{" "}
                    Vận chuyển đúng giờ{" "}
                  </h4>
                  <div className="italic sm">
                    {" "}
                    Luôn luôn đúng giờ là một ưu điểm tuyệt vời mà NETCO có được{" "}
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-12">
                  <h4 className="bold">
                    <img
                      src="tick.png"
                      className="logocustom"
                      width="20"
                    />{" "}
                    Nhân viên nhiệt tình
                  </h4>
                  <div className="italic sm">
                    {" "}
                    Nhân viên giao hàng nhiệt tình, luôn lắng nghe mọi ý kiến từ
                    khách hàng{" "}
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-6">
              <h3 className="bold mb10"> ĐĂNG NHẬP </h3>
              <div className="form-group mb30">
                Bạn chưa có tài khoản?
                <Link
                  style={{ color: "#2264D1" }}
                  className="bold"
                  to="/register"
                >
                  {" "}
                  Đăng ký ngay
                </Link>
              </div>
              <div className="form-group width60">
                <label for="exampleEmail">Email/số điện thoại </label>
                <input
                  type="text"
                  class={"form-control borradius3 " + UserActive}
                  id="exampleEmail"
                  ref={UsernameRef}
                  value={Username}
                  {...bindUserName}
                  placeholder="Nhập Email hoặc số điện thoại"
                />
              </div>
              <div className="form-group margin-top-20 width60">
                <label for="examplePass">Mật khẩu</label>
                <div className="input-group">
                  <input
                    type={PassHide}
                    class={"form-control borradius3 " + PassActive}
                    id="examplePass"
                    placeholder="Nhập mật khẩu"
                    ref={PasswordRef}
                    value={Password}
                    {...bindPassword}
                  />
                  <div className="input-group-append">
                    <span
                      className={"fa fa-fw fa-eye input-group-text " + PassEye}
                      onClick={(e) => {
                        setPassHide(PassEye === "" ? "text" : "password");
                        setPassEye(PassEye === "" ? "fa-eye-slash" : "");
                      }}
                    ></span>
                  </div>
                </div>
              </div>
              <div
                className="form-group width60"
                style={{ color: "grey", marginTop: "-5px" }}
              >
                <Link
                  className="pull-right"
                  style={{ color: "#3e3838" }}
                  to="/forgot"
                >
                  Quên mật khẩu ?
                </Link>
              </div>
              <div className="form-group text-center margin-top-20 width60">
                <button
                  type="button"
                  style={{ width: "100%" }}
                  className="margin-top-20 btn text-transform btn-sm btn-save"
                  onClick={onClickLogin}
                >
                  Đăng nhập<div className="ripple-container"></div>
                </button>
              </div>
              <div className="italic margin-top-15  mb30">{LoginMessage}</div>
            </div>
          </div>
        </div>
      </div>
    </LayoutLogin>
  );
};
