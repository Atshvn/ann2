
export * from "./LoginComponent.jsx"; //User đăng nhập
export * from "./ChangePassword.jsx"; //User đổi mật khẩu
export * from "./ForgotPassword.jsx"; //User bấm vào quên mật khẩu
export * from "./ResetPassword.jsx";//Sau khi bấm vào quên mật khẩu sẽ gửi thông tin về mail, từ email bấm vào link để vào page này tạo mật khẩu mới