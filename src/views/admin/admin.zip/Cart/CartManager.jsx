import LayoutMain from "../../layout/LayoutMain";
export const CartManager = () => {
    return (<LayoutMain></LayoutMain>)
}